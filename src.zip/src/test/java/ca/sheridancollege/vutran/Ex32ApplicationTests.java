package ca.sheridancollege.vutran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex32ApplicationTests {

	@Test
	void contextLoads() {
	}

}
