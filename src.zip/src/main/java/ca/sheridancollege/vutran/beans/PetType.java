package ca.sheridancollege.vutran.beans;

public enum PetType {
	DOG, 
	CAT, 
	FISH, 
	BIRD;
}
